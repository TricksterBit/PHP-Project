<?php
function checkAuth(string $login, string $password): bool
{

$dbh = new \PDO( 'mysql:host=a251436.mysql.mchost.ru; dbname=a251436_1',  'a251436_1', '123123123Zx');
    $dbh->exec("SET NAMES UTF8");
    $stm = $dbh->prepare('SELECT * FROM data');
    $stm->execute();
    $users = $stm->fetchAll();

    foreach ($users as $user) {
        if ($user['login'] === $login
            && $user['password'] === $password
        ) {
            return true;
        }
    }

    return false;
}

function checkReg(string $login, string $email): bool
{
$dbh = new \PDO( 'mysql:host=a251436.mysql.mchost.ru; dbname=a251436_1',  'a251436_1', '123123123Zx');
    $dbh->exec("SET NAMES UTF8");
    $stm = $dbh->prepare('SELECT * FROM data');
    $stm->execute();
    $users = $stm->fetchAll();

    foreach ($users as $user) {
        if ($user['login'] === $login
            && $user['mail'] === $email
        ) {
            return true;
        }
    }

    return false;
}

function getUserLogin(): ?string
{
    $loginFromCookie = $_COOKIE['login'] ?? '';
    $passwordFromCookie = $_COOKIE['password'] ?? '';

    if (checkAuth($loginFromCookie, $passwordFromCookie)) {
        return $loginFromCookie;
    }

    return null;
}