<?php
require __DIR__ . '/auth.php';
$login = getUserLogin();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Главная страница</title>
</head>
<body>
<?php if ($login === null): ?>
    <a href="/login.php">Авторизуйтесь</a>
    <br>
    <a href="/reg.php">Зарегистрируйтесь</a>
<?php else: ?>
    Добро пожаловать, <?= $login ?>
     <br>
    <a href="/upload.php">Загрузить картинки</a>
    <br>
    <a href="/logout.php">Выйти</a>
    <br>
<?php endif; ?>
</body>
</html>