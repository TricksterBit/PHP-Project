<?php

if (!empty($_POST)) {
    require __DIR__ . '/auth.php';

    if (!empty($_COOKIE)) {
        $login = $_COOKIE['login'];
        $password = $_COOKIE['password'];
        if (checkAuth($login, $password)) {
            header('Location: /index.php');
        }
    }
    $login = $_POST['login'] ?? '';
    $password = $_POST['password'] ?? '';

    if (checkAuth($login, $password)) {
        setcookie('login', $login, 0, '/');
        setcookie('password', $password, 0, '/');
        header('Location: /index.php');
    } else {
        $error = 'Ошибка авторизации';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Авторизация</title>
</head>
<body>
<?php if (isset($error)): ?>
    <span style="color: red;">
    <?= $error ?>
</span>
<?php endif; ?>
<form action="/login.php" method="post" autocomplete="off">
    <label for="login">Имя пользователя: </label><input type="text" name="login" id="login">
    <br>
    <label for="password">Пароль: </label><input type="password" name="password" id="password">
    <br>
    <input type="submit" value="Войти">
</form>
<br>
  <a href="/recovery.php">Забыли пароль</a>
<br><a href="/reg.php">Зарегистрироваться</a>
</body>
</html>