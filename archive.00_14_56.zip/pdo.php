<?php
$dbh = new \PDO( 'mysql:host=a251436.mysql.mchost.ru; dbname=a251436_1',  'a251436_1', '123123123Zx');
    $dbh->exec("SET NAMES UTF8");
    $stm = $dbh->prepare('SELECT * FROM data');
    $stm->execute();
    $users = $stm->fetchAll();
?>