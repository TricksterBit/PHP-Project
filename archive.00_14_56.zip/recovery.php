<?php
if(!empty($_POST['mail'])){
$dbh = new \PDO( 'mysql:host=a251436.mysql.mchost.ru; dbname=a251436_1',  'a251436_1', '123123123Zx');
$dbh->exec("SET NAMES UTF8");
$stm = $dbh->prepare('SELECT * FROM data WHERE mail = :mail');
$stm->bindValue(':mail',$_POST['mail']);  
    $stm->execute();
    $users = $stm->fetchAll();
foreach($users as $user){
mail($_POST['mail'], 'Восстановление пароля', $user['password'], 'From: denistest.ru');
header('Location: /index.php');
}
}               
  //mail(($_POST['mess'], 'Восстановление пароля', $message);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form action="/recovery.php" method="post" autocomplete="off">
  <label for="login">Ваша почта: </label><input type="text" name="mail" id="mail">
    <br>
    <input type="submit" value="Узнать пароль">
</form>
</body>
</html>