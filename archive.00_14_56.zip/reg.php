<?php
if(!empty($_POST)){
    require __DIR__ . '/auth.php';
    $login = $_POST['login'] ?? '';
    $email = $_POST['email'] ?? '';
    if(checkReg($login, $email)){
        $message = 'Данный логин или почта уже имеются на сайте';
    } else{
    $dbh = new \PDO( 'mysql:host=a251436.mysql.mchost.ru; dbname=a251436_1',  'a251436_1', '123123123Zx');
    $dbh->exec("SET NAMES UTF8");
        $stm = $dbh->prepare('INSERT INTO data (name, last_name, login, mail, password) VALUES (:name, :last_name, :login, :mail, :password)');
        $stm->bindValue('name', $_POST['first_name']);
        $stm->bindValue('last_name', $_POST['last_name']);
        $stm->bindValue('login', $_POST['login']);
        $stm->bindValue('mail', $_POST['email']);
        $stm->bindValue('password', $_POST['password']);
        $stm->execute();
        header('Location: /login.php');
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="styles/styles.css">
    <title>Регистрация</title>
</head>
<body>
<form action="/reg.php" method="post">
<?= $message ?>
    <div>
        <input type="text" id="first_name" name="first_name" required placeholder=" " />
        <label for="first_name">Имя</label>
    </div>

    <div>
        <input type="text" id="last_name" name="last_name" required placeholder=" " />
        <label for="last_name">Фамилия</label>
    </div>

    <div>
        <input type="text" id="login" name="login" required placeholder=" " />
        <label for="login">Логин</label>
    </div>

    <div>
        <input type="email" id="email" name="email" required placeholder=" " />
        <label for="email">Email</label>
        <div class="requirements">
            Укажите корректную почту
        </div>
    </div>

    <div>
        <input type="password" id="password" name="password" required placeholder=" " pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" />
        <label for="password">Пароль</label>
        <div class="requirements">Пароль должен содержать 6 символов, в том числе цифры, заглавные и строчные буквы
        </div>
    </div>

    <input type="submit" value="Зарегистрироваться" />
    <a href="/login.php">Авторизоваться</a>
</form>
</body>
</html>