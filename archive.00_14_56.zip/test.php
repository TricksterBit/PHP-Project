<?php
require __DIR__ . '/pdo.php';
foreach ($users as $user){
echo $user['login'];
}
